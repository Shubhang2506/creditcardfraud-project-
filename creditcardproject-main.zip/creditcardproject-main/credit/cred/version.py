import xgboost
print(f"XGBoost version: {xgboost.__version__}")
